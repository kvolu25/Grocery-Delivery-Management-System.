This folder contains integration test scripts for the Grocery Delivery Management System.

Instructions:
1. Ensure the application is running.
2. Run integration tests using:
   pytest --integration

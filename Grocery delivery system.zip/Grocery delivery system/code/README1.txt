This folder contains the source code for the Grocery Delivery Management System.

Instructions:
1. Ensure you have Python and Node.js installed.
2. Install backend dependencies:
   pip install -r requirements.txt
3. Install frontend dependencies:
   npm install
4. Run the backend:
   python app.py
5. Run the frontend:
   npm start

This folder contains unit test scripts for the Grocery Delivery Management System.

Instructions:
1. Navigate to the project root.
2. Run unit tests using:
   pytest

This folder contains scripts for data collection (if applicable).

Instructions:
1. Review the script comments for usage.
2. Run scripts using:
   python script_name.py

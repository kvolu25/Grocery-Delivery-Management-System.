# Placeholder for data collection script
import csv

def collect_sample_data():
    data = [
        ["Item", "Price"],
        ["Apples", 1.99],
        ["Bananas", 0.99],
        ["Milk", 2.49]
    ]
    with open("sample_data.csv", "w", newline="") as file:
        writer = csv.writer(file)
        writer.writerows(data)
    print("Sample data collected and saved to sample_data.csv")

if __name__ == "__main__":
    collect_sample_data()
